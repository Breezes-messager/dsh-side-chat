import { SideChatAskRequest } from "./protocol.js";
import { Context } from "@deepseek-ai/cordis";
import { IncomingMessage, ServerResponse } from "node:http";
//#region node_modules/.pnpm/@deepseek-ai+cosmokit@1.8.5/node_modules/@deepseek-ai/cosmokit/lib/types/types.d.ts
declare function isArrayBufferLike(value: any): value is ArrayBufferLike;
declare function isArrayBufferSource(value: any): value is Binary.Source;
/** Binary source detection and base64/hex conversion helpers. */
declare namespace Binary {
  type Source<T extends ArrayBufferLike = ArrayBufferLike> = T | ArrayBufferView<T>;
  const is: typeof isArrayBufferLike;
  const isSource: typeof isArrayBufferSource;
  function fromSource<T extends ArrayBufferLike>(source: Source<T>): T;
  function toBase64(source: Source): string;
  function fromBase64(source: string): ArrayBuffer | Uint8Array<ArrayBuffer>;
  function toHex(source: Source): string;
  function fromHex(source: string): ArrayBuffer;
}
//#endregion
//#region node_modules/.pnpm/@deepseek-ai+cosmokit@1.8.5/node_modules/@deepseek-ai/cosmokit/lib/types/misc.d.ts
/** String/symbol keyed dictionary type. */
type Dict<T = any, K extends string | symbol = string> = { [key in K]: T; };
//#endregion
//#region node_modules/.pnpm/@deepseek-ai+cosmokit@1.8.5/node_modules/@deepseek-ai/cosmokit/lib/types/volatile.d.ts
/** Shared config references used by schema validators and plugin runtimes. */
/** Recursively readonly data returned by a volatile config reference. */
type VolatileSnapshot<T> = T extends object ? { readonly [K in keyof T]: VolatileSnapshot<T[K]>; } : T;
/** A stable reference; keep the reference, or capture its value for one operation only. */
interface Volatile<T> {
  /** @returns the current immutable snapshot, including undefined for an absent value. */
  get(): VolatileSnapshot<T>;
}
//#endregion
//#region node_modules/.pnpm/@standard-schema+spec@1.1.0/node_modules/@standard-schema/spec/dist/index.d.ts
/** The Standard Typed interface. This is a base type extended by other specs. */
interface StandardTypedV1<Input = unknown, Output = Input> {
  /** The Standard properties. */
  readonly "~standard": StandardTypedV1.Props<Input, Output>;
}
declare namespace StandardTypedV1 {
  /** The Standard Typed properties interface. */
  interface Props<Input = unknown, Output = Input> {
    /** The version number of the standard. */
    readonly version: 1;
    /** The vendor name of the schema library. */
    readonly vendor: string;
    /** Inferred types associated with the schema. */
    readonly types?: Types<Input, Output> | undefined;
  }
  /** The Standard Typed types interface. */
  interface Types<Input = unknown, Output = Input> {
    /** The input type of the schema. */
    readonly input: Input;
    /** The output type of the schema. */
    readonly output: Output;
  }
  /** Infers the input type of a Standard Typed. */
  type InferInput<Schema extends StandardTypedV1> = NonNullable<Schema["~standard"]["types"]>["input"];
  /** Infers the output type of a Standard Typed. */
  type InferOutput<Schema extends StandardTypedV1> = NonNullable<Schema["~standard"]["types"]>["output"];
}
/** The Standard Schema interface. */
interface StandardSchemaV1<Input = unknown, Output = Input> {
  /** The Standard Schema properties. */
  readonly "~standard": StandardSchemaV1.Props<Input, Output>;
}
declare namespace StandardSchemaV1 {
  /** The Standard Schema properties interface. */
  interface Props<Input = unknown, Output = Input> extends StandardTypedV1.Props<Input, Output> {
    /** Validates unknown input values. */
    readonly validate: (value: unknown, options?: StandardSchemaV1.Options | undefined) => Result<Output> | Promise<Result<Output>>;
  }
  /** The result interface of the validate function. */
  type Result<Output> = SuccessResult<Output> | FailureResult;
  /** The result interface if validation succeeds. */
  interface SuccessResult<Output> {
    /** The typed output value. */
    readonly value: Output;
    /** A falsy value for `issues` indicates success. */
    readonly issues?: undefined;
  }
  interface Options {
    /** Explicit support for additional vendor-specific parameters, if needed. */
    readonly libraryOptions?: Record<string, unknown> | undefined;
  }
  /** The result interface if validation fails. */
  interface FailureResult {
    /** The issues of failed validation. */
    readonly issues: ReadonlyArray<Issue>;
  }
  /** The issue interface of the failure output. */
  interface Issue {
    /** The error message of the issue. */
    readonly message: string;
    /** The path of the issue, if any. */
    readonly path?: ReadonlyArray<PropertyKey | PathSegment> | undefined;
  }
  /** The path segment interface of the issue. */
  interface PathSegment {
    /** The key representing a path segment. */
    readonly key: PropertyKey;
  }
  /** The Standard types interface. */
  interface Types<Input = unknown, Output = Input> extends StandardTypedV1.Types<Input, Output> {}
  /** Infers the input type of a Standard. */
  type InferInput<Schema extends StandardTypedV1> = StandardTypedV1.InferInput<Schema>;
  /** Infers the output type of a Standard. */
  type InferOutput<Schema extends StandardTypedV1> = StandardTypedV1.InferOutput<Schema>;
}
//#endregion
//#region node_modules/.pnpm/@deepseek-ai+schemastery@3.18.4/node_modules/@deepseek-ai/schemastery/lib/types/index.d.ts
declare const kSchema: unique symbol;
declare global {
  namespace Schemastery {
    /** Convert primitive constructors, constants, and existing schemas into a schema type. */
    type From<X> = X extends string | number | boolean ? Schema<X> : X extends Schema<any, any, SchemaMode> ? X : X extends typeof String ? Schema<string> : X extends typeof Number ? Schema<number> : X extends typeof Boolean ? Schema<boolean> : X extends typeof Function ? Schema<Function, (...args: any[]) => any> : X extends Constructor<infer S> ? Schema<S> : never;
    type TypeS1<X> = X extends Schema<infer S, infer _T, infer _M> ? S : never;
    type Inverse<X> = X extends Schema<infer _S, infer T, infer M> ? (arg: SchemaOutput<T, M>) => void : never;
    /** Input type accepted by a schema-like value. */
    type TypeS<X> = TypeS1<From<X>>;
    /** Output type returned by a schema-like value after validation. */
    type TypeT<X> = ReturnType<From<X>>;
    /** Resolver callback used by custom schema types registered with `Schema.extend()`. */
    type Resolve = (data: any, schema: Schema, options: Options, strict?: boolean) => [any, any?];
    /** Input type accepted by one schema in an intersection. */
    type IntersectS<X> = From<X> extends Schema<infer S, infer _T, infer _M> ? S : never;
    /** Output type returned by one schema in an intersection. */
    type IntersectT<X> = Inverse<From<X>> extends ((arg: infer T) => void) ? T : never;
    type TupleS<X extends readonly any[]> = X extends readonly [infer L, ...infer R] ? [TypeS<L>?, ...TupleS<R>] : any[];
    type TupleT<X extends readonly any[]> = X extends readonly [infer L, ...infer R] ? [TypeT<L>?, ...TupleT<R>] : any[];
    type ObjectS<X extends Dict> = { [K in keyof X]?: TypeS<X[K]> | null; } & Dict;
    type ObjectT<X extends Dict> = { [K in keyof X]: TypeT<X[K]>; } & Dict;
    type Constructor<T = any> = new (...args: any[]) => T;
    /** Static constructor and factory methods exposed by the default `Schema` export. */
    interface Static {
      <T = any>(options: Partial<Schema<T>>): Schema<T>;
      new <T = any>(options: Partial<Schema<T>>): Schema<T>;
      prototype: Schema;
      /** Validate a value against a schema node and return `[output, adaptedInput?]`. */
      resolve: Resolve;
      /** Infer a schema from a primitive value, constructor, or existing schema. */
      from<X = any>(source?: X): From<X>;
      /** Register a resolver for a custom schema `type`. */
      extend(type: string, resolve: Resolve): void;
      /** Accept any value without validation. */
      any<T = any>(): Schema<T>;
      /** Accept only nullable input. */
      never(): Schema<never>;
      /** Accept exactly one constant value. */
      const<const T>(value: T): Schema<T>;
      /** Accept strings, with optional metadata constraints added by instance methods. */
      string(): Schema<string>;
      /** Accept numbers, with optional range and step constraints. */
      number(): Schema<number>;
      /** Accept non-negative integer numbers. */
      natural(): Schema<number>;
      /** Accept a number between 0 and 1 and mark it as a slider. */
      percent(): Schema<number>;
      /** Accept booleans. */
      boolean(): Schema<boolean>;
      /** Accept `Date` instances or parse datetime strings into `Date` objects. */
      date(): Schema<string | Date, Date>;
      /** Accept `RegExp` instances or parse strings into regular expressions. */
      regExp(flag?: string): Schema<string | RegExp, RegExp>;
      /** Accept binary sources and normalize them to `ArrayBufferLike`. */
      arrayBuffer(): Schema<Binary.Source, ArrayBufferLike>;
      arrayBuffer(encoding: 'hex' | 'base64'): Schema<Binary.Source | string, ArrayBufferLike>;
      /** Accept a numeric bitset or string keys and normalize to a number. */
      bitset<K extends string>(bits: Partial<Record<K, number>>): Schema<number | readonly K[], number>;
      /** Accept functions. */
      function(): Schema<Function, (...args: any[]) => any>;
      /** Accept instances of a constructor or objects whose constructor name matches. */
      is(constructor: string): Schema;
      is<T>(constructor: Constructor<T>): Schema<T>;
      /** Accept arrays whose elements match `inner`. */
      array<X>(inner: X): Schema<TypeS<X>[], TypeT<X>[]>;
      /** Accept plain objects with values matching `inner` and optional key schema. */
      dict<X, Y extends Schema<any, string> = Schema<string>>(inner: X, sKey?: Y): Schema<Dict<TypeS<X>, TypeS<Y>>, Dict<TypeT<X>, TypeT<Y>>>;
      /** Accept tuple arrays where each index matches the corresponding schema. */
      tuple<const X extends readonly any[]>(list: X): Schema<TupleS<X>, TupleT<X>>;
      /** Accept plain objects; infer fields from the dictionary, not the enclosing schema's output type. */
      object<X extends Dict>(dict: X): Schema<ObjectS<NoInfer<X>>, ObjectT<NoInfer<X>>>;
      /** Accept values matching at least one schema in `list`. */
      union<const X>(list: readonly X[]): Schema<TypeS<X>, TypeT<X>>;
      /** Accept values matching every schema in `list`, merging object outputs. */
      intersect<const X>(list: readonly X[]): Schema<IntersectS<X>, IntersectT<X>>;
      /** Validate with `inner`, then convert the result with `callback`. */
      transform<X, T>(inner: X, callback: (value: TypeS<X>, options: Schemastery.Options) => T, preserve?: boolean): Schema<TypeS<X>, T>;
      /** Defer construction of a recursive schema until validation or serialization. */
      lazy<X extends Schema<any, any, SchemaMode>>(callback: () => X): X;
      ValidationError: typeof ValidationError;
    }
    /** Runtime validation options shared by all schema calls. */
    interface Options {
      /** Remove invalid object properties instead of throwing when possible. */
      autofix?: boolean;
      /** Skip validation for selected values and schema nodes. */
      ignore?(data: any, schema: Schema): boolean;
      /** Path used to format nested validation errors. */
      path?: (keyof any)[];
    }
    /** UI and validation metadata attached by schema builder methods. */
    interface Meta<T = any> {
      default?: T extends {} ? Partial<T> : T;
      required?: boolean;
      /** Parse this node as a stable config reference; its type and UI metadata remain unchanged. */
      volatile?: boolean;
      disabled?: boolean;
      collapse?: boolean;
      badges?: {
        text: string;
        type: string;
      }[];
      hidden?: boolean;
      loose?: boolean;
      role?: string;
      extra?: any;
      link?: string;
      description?: string | Dict<string>;
      comment?: string;
      pattern?: {
        source: string;
        flags?: string;
      };
      max?: number;
      min?: number;
      step?: number;
    }
  }
  /** Callable schema instance that validates input and returns normalized output. */
  interface Schemastery<S = any, T = S, Mode extends SchemaMode = 'plain'> {
    (data?: S | null, options?: Schemastery.Options): SchemaOutput<T, Mode>;
    new (data?: S | null, options?: Schemastery.Options): SchemaOutput<T, Mode>;
    [kSchema]: true;
    uid: number;
    meta: Schemastery.Meta<T>;
    type: string;
    sKey?: Schema;
    inner?: Schema;
    list?: Schema[];
    dict?: Dict<Schema>;
    bits?: Dict<number>;
    callback?: Function;
    constructor?: string | Function;
    builder?: Function;
    value?: T;
    refs?: Dict<Schema>;
    preserve?: boolean;
    '~standard': StandardSchemaV1.Props;
    /** Format this schema as a compact TypeScript-like type string. */
    toString(inline?: boolean): string;
    /** Serialize this schema, preserving shared and recursive references. */
    toJSON(): Schema<S, T, Mode>;
    /** Mark nullable input as invalid unless a default supplies a fallback. */
    required<R extends boolean = true>(value?: R): Schema<S, T, SetRequired<Mode, R>>;
    /**
     * Parse this config field as a stable reference containing immutable data.
     * @returns a schema whose output supports get(), including when the field is absent.
     */
    volatile(): Schema<NoInfer<S>, NoInfer<T>, Mode extends 'defined' | 'volatile-defined' ? 'volatile-defined' : 'volatile'>;
    /** Hide this schema node from UI renderers. */
    hidden(value?: boolean): Schema<S, T, Mode>;
    /** Return the default value instead of throwing when validation fails. */
    loose(value?: boolean): Schema<S, T, Mode>;
    /** Attach a renderer role and optional role-specific metadata. */
    role(text: string, extra?: any): Schema<S, T, Mode>;
    /** Attach an external documentation link. */
    link(link: string): Schema<S, T, Mode>;
    /** Set the fallback value used for nullable input. */
    default(value: T | NoInfer<Partial<S>>): Schema<S, T, SetRequired<Mode, true>>;
    /** Attach an auxiliary comment for documentation or form UIs. */
    comment(text: string): Schema<S, T, Mode>;
    /** Attach a localized or plain description for documentation or form UIs. */
    description(text: string): Schema<S, T, Mode>;
    /** Mark this schema node as disabled for form UIs. */
    disabled(value?: boolean): Schema<S, T, Mode>;
    /** Request collapsed rendering for nested form UIs. */
    collapse(value?: boolean): Schema<S, T, Mode>;
    /** Add a deprecated badge to this schema node. */
    deprecated(): Schema<S, T, Mode>;
    /** Add an experimental badge to this schema node. */
    experimental(): Schema<S, T, Mode>;
    /** Require strings to match a regular expression. */
    pattern(regexp: RegExp): Schema<S, T, Mode>;
    /** Set an inclusive maximum for numbers or collection lengths. */
    max(value: number): Schema<S, T, Mode>;
    /** Set an inclusive minimum for numbers or collection lengths. */
    min(value: number): Schema<S, T, Mode>;
    /** Set the numeric increment constraint. */
    step(value: number): Schema<S, T, Mode>;
    /** Add or replace an object property schema. */
    set(key: string, value: Schema): Schema<S, T, Mode>;
    /** Append a tuple, union, or intersection member schema. */
    push(value: Schema): Schema<S, T, Mode>;
    /** Remove values equal to schema defaults from normalized output. */
    simplify(value?: any): any;
    /** Return a schema clone with descriptions merged from locale messages. */
    i18n(messages: Dict): Schema<S, T, Mode>;
    /** Attach arbitrary metadata consumed by form renderers and downstream tools. */
    extra<K extends keyof Schemastery.Meta>(key: K, value: Schemastery.Meta[K]): Schema<S, T, Mode>;
  }
}
declare class ValidationError extends TypeError {
  options: Schemastery.Options;
  name: string;
  constructor(message: string, options: Schemastery.Options);
  static is(error: any): error is ValidationError;
}
type SchemaMode = 'plain' | 'defined' | 'volatile' | 'volatile-defined';
type SchemaOutput<T, M extends SchemaMode> = M extends 'volatile' ? Volatile<T | undefined> : M extends 'volatile-defined' ? Volatile<T> : T;
type SetRequired<M extends SchemaMode, R extends boolean> = M extends 'volatile' | 'volatile-defined' ? R extends true ? 'volatile-defined' : 'volatile' : R extends true ? 'defined' : 'plain';
type Schema<S = any, T = S, Mode extends SchemaMode = 'plain'> = Schemastery<S, T, Mode>;
declare const Schema: Schemastery.Static;
//#endregion
//#region src/context.d.ts
/** How much Session context the prompt may carry. */
interface ContextBudget {
  /** Most recent messages kept when the request names no exact messages. */
  readonly recentMessages: number;
  /** Longest single message kept, in characters. */
  readonly maxMessageChars: number;
  /** Longest whole context block kept, in characters. */
  readonly maxContextChars: number;
}
//#endregion
//#region src/index.d.ts
/** Cordis plugin name. */
declare const name = "side-chat";
/** The route needs the web server; an answer needs a model route. */
declare const inject: string[];
/** One token-level chunk of a model call, as this plugin reads it. */
interface LlmStreamChunk {
  readonly type: string;
  readonly text?: string;
  readonly reason?: {
    readonly kind?: string;
    readonly failure?: {
      readonly message?: string;
      readonly code?: string;
      readonly status?: number;
    };
  };
}
/** The slice of the `llm` service this plugin uses. */
interface LlmLike {
  stream(options: {
    readonly provider: string;
    readonly model: string;
    readonly system?: string;
    readonly messages: readonly unknown[];
    /** The Session whose route is being used; adapters resolve request credentials from it. */
    readonly sessionId?: string;
    readonly signal?: AbortSignal;
  }): AsyncIterable<LlmStreamChunk>;
}
/** The slice of the `webServer` service this plugin uses. */
interface WebServerLike {
  register(route: {
    readonly kind: 'exact' | 'prefix';
    readonly path: string;
    readonly handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>;
  }): () => void;
}
declare module '@deepseek-ai/cordis' {
  interface Context {
    llm: LlmLike;
    webServer: WebServerLike;
  }
}
/** How the route decides whether a caller may use it. */
type TrustMode = 'host' | 'same-origin' | 'open';
/** Every accepted {@link TrustMode}, for validation and documentation. */
declare const TRUST_MODES: readonly TrustMode[];
/**
 * The policy an installation gets without saying anything.
 *
 * `'same-origin'` is the safe default: the browser half is the only intended
 * caller, and it always sends an `Origin` naming the page it runs on, so the
 * panel keeps working while a cross-site page and a bare local script do not.
 * See the module documentation for what it does and does not protect against,
 * and for the deployments that should choose `'host'` or `'open'` instead.
 */
declare const DEFAULT_TRUST: TrustMode;
/** Largest accepted request body, in bytes. */
declare const DEFAULT_MAX_BODY_BYTES: number;
/** Concurrent answers allowed across the whole Host. */
declare const DEFAULT_MAX_CONCURRENT = 4;
/**
 * Hard ceiling on one answer, in milliseconds.
 *
 * A wedged provider would otherwise hold its concurrency slot for the life of
 * the process; ten minutes is far beyond any answer a person waits for and still
 * guarantees the slot comes back. `0` disables the ceiling.
 */
declare const DEFAULT_TIMEOUT_MS = 600000;
/** Longest selected text kept as context. */
declare const MAX_SELECTION_CHARS = 8000;
/** Readable fallback shown when no model route can be resolved. */
declare const NO_ROUTE_MESSAGE: string;
/** Readable fallback shown when the Host carries no `llm` service. */
declare const NO_MODEL_SERVICE_MESSAGE = "This Harness has no model service for the side chat to use.";
/** Readable fallback shown when an answer passes its time limit. */
declare const TIMEOUT_MESSAGE: string;
/** Readable fallback shown when something unexpected broke the turn. */
declare const INTERNAL_ERROR_MESSAGE: string;
/**
 * Operator-tunable limits; every field has a working default.
 *
 * The profile carries these under this entry's `config:` block, and the Loader
 * validates that block against the runtime schema exported below before `apply`
 * runs. Because a value can still reach `apply` by another route, every field is
 * re-checked here too.
 */
interface Config {
  /** Largest accepted request body, in bytes. Default `262144`. */
  readonly maxBodyBytes?: number;
  /** Concurrent answers allowed across the whole Host. Default `4`. */
  readonly maxConcurrent?: number;
  /** Most recent Session messages used as context when none are named. Default `20`. */
  readonly recentMessages?: number;
  /** Longest single context message, in characters. Default `4000`. */
  readonly maxMessageChars?: number;
  /** Longest whole context excerpt, in characters. Default `24000`. */
  readonly maxContextChars?: number;
  /** Explicit model route override; absent follows the Session's own route. */
  readonly provider?: string;
  readonly model?: string;
  /**
   * Who may use the route: `'same-origin'` (the default), `'host'`, or `'open'`.
   *
   * `'same-origin'` refuses a cross-site `Origin` and otherwise defers to the
   * Host's own check, which is what makes the web page and the desktop app both
   * work — the desktop app's forwarded request carries no `Origin` at all. It is
   * not a fence against a local program that forges headers. Choose `'host'` to
   * skip the `Origin` comparison entirely, or `'open'` to skip every check. An
   * unrecognized value is refused by the schema, or falls back to the default with
   * a warning when it arrives by another route.
   */
  readonly trust?: TrustMode;
  /** Hard ceiling on one answer, in milliseconds; `0` disables it. Default `600000`. */
  readonly timeoutMs?: number;
}
/**
 * The runtime Config schema: what the Loader validates and what DSH projects.
 *
 * DSH's Config projection reports an entry only when its module exports a native
 * Schemastery schema — `Symbol.for('schemastery') === true`, a string `type`, and
 * a `meta` object — which is exactly what this export is. Without it the profile
 * block still reached `apply`, but nothing checked it and the plugin manager had
 * nothing to show; with it, `cordis.patch.yml` refuses a bad value with a message
 * naming the field, and the fields become visible configuration.
 *
 * Schemastery comes from `@deepseek-ai/schemastery`, the version the Cordis
 * Loader itself uses, and it is a `dependencies` entry rather than a dev one so
 * the package is honest about what it needs to build. **Nothing is required at
 * the user's end, though: `tsdown` inlines it into `lib/index.js`** (see
 * `INLINED_RUNTIME` in `tsdown.config.ts`), because a DSH profile has no reason
 * to hold Schemastery for a plugin's sake. The bare specifier is left in
 * `package.json` for the build, and the artifact imports nothing but its own
 * sibling module.
 */
declare const Config: Schema<Schemastery.ObjectS<NoInfer<{
  maxBodyBytes: Schema<number, number, "defined">;
  maxConcurrent: Schema<number, number, "defined">;
  recentMessages: Schema<number, number, "defined">;
  maxMessageChars: Schema<number, number, "defined">;
  maxContextChars: Schema<number, number, "defined">;
  provider: Schema<string, string, "plain">;
  model: Schema<string, string, "plain">;
  /**
   * Deliberately without `.default()`.
   *
   * The development switch `DSH_SIDE_CHAT_ALLOW_LOOPBACK=1` selects `'open'`
   * only while the profile says nothing about trust. A schema default would
   * materialize the default into every config block and silently outrank that
   * switch; the default lives in {@link DEFAULT_TRUST} and in this description
   * instead.
   */
  trust: Schema<"host" | "same-origin" | "open", "host" | "same-origin" | "open", "plain">;
  timeoutMs: Schema<number, number, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
  maxBodyBytes: Schema<number, number, "defined">;
  maxConcurrent: Schema<number, number, "defined">;
  recentMessages: Schema<number, number, "defined">;
  maxMessageChars: Schema<number, number, "defined">;
  maxContextChars: Schema<number, number, "defined">;
  provider: Schema<string, string, "plain">;
  model: Schema<string, string, "plain">;
  /**
   * Deliberately without `.default()`.
   *
   * The development switch `DSH_SIDE_CHAT_ALLOW_LOOPBACK=1` selects `'open'`
   * only while the profile says nothing about trust. A schema default would
   * materialize the default into every config block and silently outrank that
   * switch; the default lives in {@link DEFAULT_TRUST} and in this description
   * instead.
   */
  trust: Schema<"host" | "same-origin" | "open", "host" | "same-origin" | "open", "plain">;
  timeoutMs: Schema<number, number, "defined">;
}>>, "plain">;
/** One resolved model route. */
interface ModelRoute {
  readonly provider: string;
  readonly model: string;
}
/** Everything the route needs, resolved once from operator config. */
interface Settings {
  readonly maxBodyBytes: number;
  readonly maxConcurrent: number;
  readonly timeoutMs: number;
  readonly trust: TrustMode;
  /** Where {@link Settings.trust} came from, so the plugin can log the policy it runs. */
  readonly trustSource: 'config' | 'environment' | 'default';
  readonly budget: ContextBudget;
  /** The `provider`/`model` override from config, when both are usable. */
  readonly route: ModelRoute | undefined;
}
/** Read a configured trust policy, or `undefined` for a missing or unusable one. */
declare function normalizeTrust(value: unknown): TrustMode | undefined;
/**
 * Resolve operator config into the values one route instance runs with.
 * @param config - the profile's `config:` block, of unverified shape.
 * @param options - `allowLoopback` mirrors the development switch.
 * @returns bounded numbers, the effective trust policy, and an optional route.
 */
declare function settingsOf(config?: Config, options?: {
  readonly allowLoopback?: boolean;
}): Settings;
/** One caller's request, as the trust policy reads it. */
interface TrustInput {
  /** The effective policy. */
  readonly mode: TrustMode;
  /** What the Host's `connection` service answered, or `undefined` when it admitted the request. */
  readonly rejection: 401 | 403 | undefined;
  /** Whether the request arrived over the loopback interface. */
  readonly loopback: boolean;
  /** The request's `Origin` header, when it carried one. */
  readonly origin: string | undefined;
  /** The request's `Host` header, when it carried one. */
  readonly host: string | undefined;
}
/** The outcome of applying {@link TrustInput}. */
type TrustDecision = {
  readonly allowed: true;
  readonly basis: 'open' | 'host-accepted' | 'host-authenticated' | 'same-origin';
} | {
  readonly allowed: false;
  readonly status: 401 | 403;
  readonly basis: 'host-rejection' | 'not-loopback' | 'origin-opaque' | 'origin-mismatch';
};
/**
 * Whether the request arrived over the loopback interface.
 *
 * Loopback is not a trust boundary on a shared machine: any local process can
 * reach this port, and this route can fold the user's own conversation into a
 * model answer. What actually keeps those processes out is the Host's own
 * credential — measured: a request without it is refused (401) before this route
 * is reached. The plugin's `trust` policy is the layer *after* that: `'host'`
 * leaves the decision entirely to Connection, and `'same-origin'` additionally
 * refuses a cross-site `Origin` and a non-loopback caller.
 */
declare function isLoopback(req: IncomingMessage): boolean;
/**
 * Whether an `Origin` header names the very authority the request was addressed to.
 *
 * Deliberately scheme-agnostic: the comparison is over hostname and effective
 * port, so `https://127.0.0.1:19387` matches a `Host` of `127.0.0.1:19387`. That
 * is intentional, not an oversight. What this check bounds is *which page* may
 * speak to the route — a browser puts its own origin in the header and cannot be
 * talked out of it — and a differing scheme does not give an attacker anything a
 * matching scheme would not: the `Host` header carries no scheme to compare
 * against, and a local process that can forge one header can forge the other
 * too. Requiring a scheme match would only reject honest callers behind a
 * TLS-terminating proxy.
 * @param origin - the request's `Origin`, as a URL.
 * @param hostHeader - the request's `Host`.
 * @returns true only for an http(s) origin whose hostname and effective port match.
 */
declare function sameOrigin(origin: string, hostHeader: string | undefined): boolean;
/**
 * Apply one trust policy to one request. Pure: every input is a value.
 *
 * `'same-origin'` reads the `Origin` header when there is one and defers to the
 * Host when there is not, in this order:
 *
 * 1. a Host rejection outranks everything;
 * 2. no `Origin` — the desktop app's Electron forwarder strips it and re-adds
 *    only the Host's cookie, and a non-browser caller never sends one — so the
 *    Host's own answer, already folded into {@link TrustInput.rejection}, is the
 *    authentication decision;
 * 3. an opaque `Origin: null` (a sandboxed iframe, a `data:` page) is refused;
 * 4. an `Origin` that does not name the addressed authority is refused — a
 *    cross-site page always sends its own, and cannot be talked out of it;
 * 5. otherwise the request is the panel's own.
 *
 * Step 2 is why the desktop app works at all, and it is still stricter than
 * `'host'`: that mode never looks at `Origin`, so it accepts a cross-site page
 * whenever the Host has no authentication configured. This one does not.
 * @param input - the policy, the Host's answer, and the headers the policy reads.
 * @returns whether the request may proceed, and on what basis.
 */
declare function decideTrust(input: TrustInput): TrustDecision;
/** Why a body could not be used. */
type BodyFailure = 'too-large' | 'aborted';
/** One request body, or why it was refused. */
type BodyResult = {
  readonly ok: true;
  readonly text: string;
} | {
  readonly ok: false;
  readonly reason: BodyFailure;
};
/**
 * Read and bound a request body.
 *
 * A body over the limit stops the read immediately — the request is paused
 * rather than drained, so an oversized upload cannot spend the Host's bandwidth
 * — and the caller answers `413` while the connection is closed. A declared
 * `content-length` above the limit is refused without reading a byte.
 * @param req - the incoming request.
 * @param limit - largest body accepted, in bytes.
 * @returns the body text, or the reason it was refused.
 */
declare function readBody(req: IncomingMessage, limit: number): Promise<BodyResult>;
/** Parse one request body into this route's request shape. */
declare function parseRequest(body: string): SideChatAskRequest | undefined;
/**
 * Mount the side-chat route.
 * @param ctx - Host context carrying the web server and the model service.
 * @param config - operator limits, the trust policy, and the optional model override.
 */
declare function apply(ctx: Context, config?: Config): void;
//#endregion
export { Config, DEFAULT_MAX_BODY_BYTES, DEFAULT_MAX_CONCURRENT, DEFAULT_TIMEOUT_MS, DEFAULT_TRUST, INTERNAL_ERROR_MESSAGE, MAX_SELECTION_CHARS, ModelRoute, NO_MODEL_SERVICE_MESSAGE, NO_ROUTE_MESSAGE, Settings, TIMEOUT_MESSAGE, TRUST_MODES, TrustDecision, TrustInput, TrustMode, apply, decideTrust, inject, isLoopback, name, normalizeTrust, parseRequest, readBody, sameOrigin, settingsOf };